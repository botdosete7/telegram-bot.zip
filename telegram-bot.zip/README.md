# 🤖 Bot do Telegram no Railway (Versão Avançada)

Este é um bot do Telegram rodando 24h no **Railway**.  
Além dos comandos básicos, ele já vem com recursos extras como salvar mensagens e enviar imagens.

---

## 🚀 Como rodar no Railway

### 1. Criar um repositório no GitHub
- Vá até [GitHub](https://github.com) e crie um novo repositório (ex: `telegram-bot`).
- Faça upload destes arquivos (`index.js`, `package.json` e `README.md`).

### 2. Conectar no Railway
- Acesse [Railway](https://railway.app).
- Clique em **New Project → Repositório GitHub**.
- Escolha o repositório que você acabou de criar.

### 3. Configurar variáveis de ambiente
No painel do Railway, vá em **Settings → Variables** e adicione:

- **Key:** `TELEGRAM_TOKEN`
- **Value:** o token do bot que você pegou no **BotFather** no Telegram.

### 4. Deploy
- O Railway vai instalar as dependências automaticamente (`node-telegram-bot-api`).
- Ele vai rodar o comando `npm start`, que inicia o bot.
- No console deve aparecer:  
  ```
  ✅ Bot avançado do Telegram rodando no Railway!
  ```

### 5. Testar no Telegram
Abra o Telegram e fale com o seu bot (o @username que você criou no BotFather).  
Testes disponíveis:

- `/start` → mensagem de boas-vindas  
- `/help` → lista de comandos  
- `/echo teste` → repete "teste"  
- `/info` → mostra informações do usuário  
- `/hora` → mostra a hora atual (Brasil)  
- `/foto` → envia uma imagem aleatória da internet  
- `/salvar <texto>` → guarda a frase enviada  
- `/listar` → mostra todas as frases salvas  
- Qualquer outra mensagem → responde "Você disse: ..."  

---

## 📌 Personalização
- Você pode editar o arquivo `index.js` e adicionar novos comandos.  
- Após mudar, basta fazer commit no GitHub e o Railway atualiza sozinho.  

---

Feito com ❤️ para rodar bots avançados no **Railway + Telegram**.
