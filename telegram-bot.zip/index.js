const TelegramBot = require('node-telegram-bot-api');
const token = process.env.TELEGRAM_TOKEN;
const bot = new TelegramBot(token, { polling: true });

// Memória simples em array
let mensagensSalvas = [];

// /start
bot.onText(/\/start/, (msg) => {
  bot.sendMessage(msg.chat.id, "👋 Olá! Eu sou seu bot do Telegram rodando no Railway.\n\nDigite /help para ver os comandos disponíveis.");
});

// /help
bot.onText(/\/help/, (msg) => {
  bot.sendMessage(msg.chat.id,
    "📌 Comandos disponíveis:\n\n" +
    "/start - Inicia a conversa\n" +
    "/help - Mostra os comandos\n" +
    "/echo <texto> - Repete sua mensagem\n" +
    "/info - Mostra informações do usuário\n" +
    "/hora - Mostra a hora atual\n" +
    "/foto - Envia uma imagem\n" +
    "/salvar <texto> - Salva uma frase\n" +
    "/listar - Mostra as frases salvas"
  );
});

// /echo
bot.onText(/\/echo (.+)/, (msg, match) => {
  bot.sendMessage(msg.chat.id, `🔁 ${match[1]}`);
});

// /info
bot.onText(/\/info/, (msg) => {
  const user = msg.from;
  bot.sendMessage(msg.chat.id, `ℹ️ Seu nome: ${user.first_name}\nID: ${user.id}\nUsername: @${user.username || "não definido"}`);
});

// /hora
bot.onText(/\/hora/, (msg) => {
  const hora = new Date().toLocaleString("pt-BR", { timeZone: "America/Sao_Paulo" });
  bot.sendMessage(msg.chat.id, `⏰ Agora são: ${hora}`);
});

// /foto
bot.onText(/\/foto/, (msg) => {
  bot.sendPhoto(msg.chat.id, "https://picsum.photos/400", { caption: "📷 Aqui está uma foto aleatória!" });
});

// /salvar
bot.onText(/\/salvar (.+)/, (msg, match) => {
  mensagensSalvas.push(match[1]);
  bot.sendMessage(msg.chat.id, "✅ Mensagem salva!");
});

// /listar
bot.onText(/\/listar/, (msg) => {
  if (mensagensSalvas.length === 0) {
    bot.sendMessage(msg.chat.id, "⚠️ Nenhuma mensagem salva ainda.");
  } else {
    bot.sendMessage(msg.chat.id, "📒 Mensagens salvas:\n- " + mensagensSalvas.join("\n- "));
  }
});

// Resposta padrão
bot.on("message", (msg) => {
  if (!msg.text.startsWith("/")) {
    bot.sendMessage(msg.chat.id, `🤖 Você disse: ${msg.text}`);
  }
});

console.log("✅ Bot avançado do Telegram rodando no Railway!");
